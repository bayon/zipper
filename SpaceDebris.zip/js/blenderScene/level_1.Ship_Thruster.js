{

	"metadata" :
	{
		"formatVersion" : 3.1,
		"generatedBy"   : "Blender 2.66 Exporter",
		"vertices"      : 9,
		"faces"         : 8,
		"normals"       : 9,
		"colors"        : 0,
		"uvs"           : [10],
		"materials"     : 1,
		"morphTargets"  : 0,
		"bones"         : 0
	},

	"scale" : 1.000000,

	"materials" : [	{
		"DbgColor" : 15658734,
		"DbgIndex" : 0,
		"DbgName" : "mat_Ship",
		"blending" : "NormalBlending",
		"colorAmbient" : [0.6400000190734865, 0.6400000190734865, 0.6400000190734865],
		"colorDiffuse" : [0.6400000190734865, 0.6400000190734865, 0.6400000190734865],
		"colorSpecular" : [0.5, 0.5, 0.5],
		"depthTest" : true,
		"depthWrite" : true,
		"mapDiffuse" : "UV_Shuttle_DIFF.jpg",
		"mapDiffuseWrap" : ["repeat", "repeat"],
		"mapNormal" : "UV_Shuttle_NORM.jpg",
		"mapNormalFactor" : 0.5,
		"mapNormalWrap" : ["repeat", "repeat"],
		"mapSpecular" : "UV_Shuttle_SPEC.jpg",
		"mapSpecularWrap" : ["repeat", "repeat"],
		"shading" : "Phong",
		"specularCoef" : 50,
		"transparency" : 1.0,
		"transparent" : false,
		"vertexColors" : false
	}],

	"vertices" : [0,0.2,-0.0555556,0.141421,0.141421,-0.0555556,0.2,0,-0.0555556,0,0,0.444444,0.141421,-0.141421,-0.0555556,-2.98023e-08,-0.2,-0.0555556,-0.141421,-0.141421,-0.0555556,-0.2,0,-0.0555556,-0.141421,0.141421,-0.0555556],

	"morphTargets" : [],

	"normals" : [-0.928465,0,0.37138,0,0,1,-0.656514,0.656514,0.37138,0,0.928465,0.37138,0.656514,0.656514,0.37138,0.928465,0,0.37138,-0.656514,-0.656514,0.37138,0,-0.928465,0.37138,0.656514,-0.656514,0.37138],

	"colors" : [],

	"uvs" : [[0.626361,0.57484,0.589426,0.598647,0.618171,0.565409,0.607657,0.558664,0.595671,0.555149,0.58318,0.555149,0.631568,0.586194,0.560681,0.565409,0.55249,0.57484,0.571194,0.558664]],

	"faces" : [42,7,3,8,0,0,1,2,0,1,2,42,0,3,1,0,3,1,4,3,1,4,42,3,0,8,0,1,3,2,1,3,2,42,1,3,2,0,4,1,5,4,1,5,42,6,3,7,0,6,1,0,6,1,0,42,5,3,6,0,7,1,8,7,1,6,42,4,3,5,0,9,1,7,8,1,7,42,2,3,4,0,5,1,9,5,1,8],

	"bones" : [],

	"skinIndices" : [],

	"skinWeights" : [],

	"animation" : {}


}
