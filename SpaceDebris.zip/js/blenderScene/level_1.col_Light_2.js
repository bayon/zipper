{

	"metadata" :
	{
		"formatVersion" : 3.1,
		"generatedBy"   : "Blender 2.66 Exporter",
		"vertices"      : 8,
		"faces"         : 6,
		"normals"       : 8,
		"colors"        : 0,
		"uvs"           : [],
		"materials"     : 1,
		"morphTargets"  : 0,
		"bones"         : 0
	},

	"scale" : 1.000000,

	"materials" : [	{
		"DbgColor" : 15658734,
		"DbgIndex" : 0,
		"DbgName" : "mat_Collison",
		"blending" : "NormalBlending",
		"colorAmbient" : [0.5025000170245768, 0.34859905289838977, 0.12319478104866732],
		"colorDiffuse" : [0.5025000170245768, 0.34859905289838977, 0.12319478104866732],
		"colorSpecular" : [0.0, 0.0, 0.0],
		"depthTest" : true,
		"depthWrite" : true,
		"shading" : "Lambert",
		"specularCoef" : 50,
		"transparency" : 0.578125,
		"transparent" : true,
		"vertexColors" : false
	}],

	"vertices" : [-1,-1,-1,-1,1,-1,1,1,-1,1,-1,-1,-1,-1,1,-1,1,1,1,1,1,1,-1,1],

	"morphTargets" : [],

	"normals" : [-0.577349,0.577349,-0.577349,-0.577349,-0.577349,-0.577349,-0.577349,-0.577349,0.577349,-0.577349,0.577349,0.577349,0.577349,0.577349,0.577349,0.577349,0.577349,-0.577349,0.577349,-0.577349,0.577349,0.577349,-0.577349,-0.577349],

	"colors" : [],

	"uvs" : [],

	"faces" : [35,1,0,4,5,0,0,1,2,3,35,5,6,2,1,0,3,4,5,0,35,6,7,3,2,0,4,6,7,5,35,0,3,7,4,0,1,7,6,2,35,0,1,2,3,0,1,0,5,7,35,7,6,5,4,0,6,4,3,2],

	"bones" : [],

	"skinIndices" : [],

	"skinWeights" : [],

	"animation" : {}


}
