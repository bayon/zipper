{

	"metadata" :
	{
		"formatVersion" : 3.1,
		"generatedBy"   : "Blender 2.66 Exporter",
		"vertices"      : 4,
		"faces"         : 1,
		"normals"       : 1,
		"colors"        : 0,
		"uvs"           : [4],
		"materials"     : 1,
		"morphTargets"  : 0,
		"bones"         : 0
	},

	"scale" : 1.000000,

	"materials" : [	{
		"DbgColor" : 15658734,
		"DbgIndex" : 0,
		"DbgName" : "mat_ship_antenna",
		"blending" : "NormalBlending",
		"colorAmbient" : [0.0, 0.0, 0.0],
		"colorDiffuse" : [0.0, 0.0, 0.0],
		"colorSpecular" : [0.0, 0.0, 0.0],
		"depthTest" : true,
		"depthWrite" : true,
		"mapDiffuse" : "Antenna.png",
		"mapDiffuseWrap" : ["repeat", "repeat"],
		"shading" : "Lambert",
		"specularCoef" : 50,
		"transparency" : 1.0,
		"transparent" : true,
		"vertexColors" : false
	}],

	"vertices" : [-0.16877,-5.43374,0,0.16877,-5.43374,0,-0.16877,5.43374,0,0.16877,5.43374,0],

	"morphTargets" : [],

	"normals" : [0,0,-1],

	"colors" : [],

	"uvs" : [[-0.013064,-0.005604,0.879749,-0.005604,0.879747,0.999577,-0.013082,0.999577]],

	"faces" : [43,1,0,2,3,0,0,1,2,3,0,0,0,0],

	"bones" : [],

	"skinIndices" : [],

	"skinWeights" : [],

	"animation" : {}


}
