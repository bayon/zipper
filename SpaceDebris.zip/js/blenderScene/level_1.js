{

"metadata" :
{
	"formatVersion" : 3.2,
	"type"          : "scene",
	"sourceFile"    : "level_1.blend",
	"generatedBy"   : "Blender 2.66 Exporter",
	"objects"       : 82,
	"geometries"    : 25,
	"materials"     : 9,
	"textures"      : 15
},

"urlBaseType" : "relativeToScene",


"objects" :
{
	"grp_Asteroid_small2" : {
		"groups"    : [  ],
		"position"  : [ 11.2461, 6.0785, -0.534216 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 1, 1, 1 ]
	},

	"Player_Ship" : {
		"groups"    : [  ],
		"position"  : [ -10.4825, 5.44546, -0.473924 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 1, 1, 1 ]
	},

	"Antenna.005" : {
		"geometry"  : "geo_Antenna.000",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_ship_antenna",
		"position"  : [ -10.3193, 5.8294, -1.14459 ],
		"rotation"  : [ 1.09726e-07, 3.14159, -1.13999e-14 ],
		"quaternion": [ -1.55788e-15, 1, 5.48632e-08, 7.54979e-08 ],
		"scale"     : [ 0.128025, 0.156547, 0.128025 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Antenna.004" : {
		"geometry"  : "geo_Antenna.000",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_ship_antenna",
		"position"  : [ -10.2313, 5.74549, -1.14459 ],
		"rotation"  : [ 1.09726e-07, 3.14159, -1.13999e-14 ],
		"quaternion": [ -1.55788e-15, 1, 5.48632e-08, 7.54979e-08 ],
		"scale"     : [ 0.128025, 0.129457, 0.128025 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_conductor.001" : {
		"geometry"  : "geo_Ship_conductor",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -9.94923, 5.04432, 0.013728 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Thruster.004" : {
		"geometry"  : "geo_Ship_Thruster",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.3188, 4.4858, -0.314058 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Thruster.003" : {
		"geometry"  : "geo_Ship_Thruster",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.3188, 4.4858, -0.653145 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Thruster.002" : {
		"geometry"  : "geo_Ship_Thruster",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.6494, 4.4858, -0.653145 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Foot.004" : {
		"geometry"  : "geo_Ship_Foot",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.4833, 4.59232, -1.55723 ],
		"rotation"  : [ -1.5708, -2.98023e-08, -1.5708 ],
		"quaternion": [ -0.5, -0.5, -0.5, 0.5 ],
		"scale"     : [ 0.787675, 0.787676, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Foot.003" : {
		"geometry"  : "geo_Ship_Foot",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.4831, 4.59232, 0.593795 ],
		"rotation"  : [ -1.5708, 0, 1.5708 ],
		"quaternion": [ -0.5, 0.5, 0.5, 0.5 ],
		"scale"     : [ 0.787675, 0.787676, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Foot.002" : {
		"geometry"  : "geo_Ship_Foot",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -9.40767, 4.59232, -0.481847 ],
		"rotation"  : [ 1.5708, -3.14159, 0 ],
		"quaternion": [ -5.33851e-08, 0.707107, 0.707107, -5.33851e-08 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Thruster.001" : {
		"geometry"  : "geo_Ship_Thruster",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.6494, 4.4858, -0.312157 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Foot.001" : {
		"geometry"  : "geo_Ship_Foot",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -11.5587, 4.59232, -0.481587 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.787676, 0.787675, 0.787675 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Ship_Head.001" : {
		"geometry"  : "geo_Ship_Head",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Ship",
		"position"  : [ -10.4832, 5.42026, -0.481717 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.723993, 0.723993, 0.723993 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"grp_Asteroid_small" : {
		"groups"    : [  ],
		"position"  : [ 5.11948, 19.3479, -0.679632 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 1, 1, 1 ]
	},

	"col_Asteroid_small_1.001" : {
		"geometry"  : "geo_col_Asteroid_small_1",
		"groups"    : [ "grp_Asteroid_small", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 5.19572, 19.502, -0.578643 ],
		"rotation"  : [ 1.5708, -3.14159, 1.50729e-14 ],
		"quaternion": [ -5.33851e-08, 0.707107, 0.707107, -5.33851e-08 ],
		"scale"     : [ 4.02418, 3.68938, 2.76837 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"SolarPanal.002" : {
		"geometry"  : "geo_SolarPanal",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "mat_Satelite",
		"position"  : [ 19.3826, 4.21312, -5.48815e-07 ],
		"rotation"  : [ -3.14159, 0, -0 ],
		"quaternion": [ 1, 0, 0, -4.74142e-09 ],
		"scale"     : [ 0.7431, 0.7431, 0.7431 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"SolarPanal.001" : {
		"geometry"  : "geo_SolarPanal",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "mat_Satelite",
		"position"  : [ -11.482, -5.34924, -8.76121e-07 ],
		"rotation"  : [ -3.14159, 0, -0 ],
		"quaternion": [ 1, 0, 0, -4.74142e-09 ],
		"scale"     : [ 0.7431, 0.7431, 0.7431 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Sattelite_1_cell.011" : {
		"geometry"  : "geo_Sattelite_1_cell.011",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "",
		"position"  : [ 4.57956, -1.99307, -0.349375 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.882129, 0.882129, 0.882129 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Sattelite_1_cell.010" : {
		"geometry"  : "geo_Sattelite_1_cell.010",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "",
		"position"  : [ -21.1959, 18.2494, 0.154885 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.882129, 0.882129, 0.882129 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Sattelite_1_cell.009" : {
		"geometry"  : "geo_Sattelite_1_cell.009",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "",
		"position"  : [ 9.24794, 12.5479, -0.383116 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.882129, 0.882129, 0.882129 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Sattelite_1_cell.008" : {
		"geometry"  : "geo_Sattelite_1_cell.008",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "",
		"position"  : [ -4.36556, 18.8921, 0.412713 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.882129, 0.882129, 0.882129 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Sattelite_1_cell.007" : {
		"geometry"  : "geo_Sattelite_1_cell.007",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "",
		"position"  : [ 1.12854, 9.81477, 0.339278 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.882129, 0.882129, 0.882129 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Sattelite_1_cell.006" : {
		"geometry"  : "geo_Sattelite_1_cell.006",
		"groups"    : [ "Satelite_Debris" ],
		"material"  : "",
		"position"  : [ 15.5504, 19.7807, -0.151396 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.882129, 0.882129, 0.882129 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Ship_Head.001" : {
		"geometry"  : "geo_col_Ship_Head",
		"groups"    : [ "Player_Ship" ],
		"material"  : "mat_Collison",
		"position"  : [ -10.4641, 5.1488, -0.42902 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 1.49747, 1.18948, 1.10234 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Antenna.003" : {
		"geometry"  : "geo_Antenna.000",
		"groups"    : [  ],
		"material"  : "mat_ship_antenna",
		"position"  : [ -11.5745, 4.51366, -2.38519 ],
		"rotation"  : [ 1.09726e-07, 3.14159, -1.13999e-14 ],
		"quaternion": [ -1.55787e-15, 1, 5.48632e-08, 7.54979e-08 ],
		"scale"     : [ 0.162535, 0.0930185, 0.162535 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Antenna.002" : {
		"geometry"  : "geo_Antenna.000",
		"groups"    : [  ],
		"material"  : "mat_ship_antenna",
		"position"  : [ -11.7838, 4.51366, -2.38519 ],
		"rotation"  : [ 1.09726e-07, 3.14159, -1.13999e-14 ],
		"quaternion": [ -1.55787e-15, 1, 5.48632e-08, 7.54979e-08 ],
		"scale"     : [ 0.162535, 0.0930185, 0.162535 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Antenna.001" : {
		"geometry"  : "geo_Antenna.000",
		"groups"    : [  ],
		"material"  : "mat_ship_antenna",
		"position"  : [ -11.6847, 4.80773, -2.38519 ],
		"rotation"  : [ 1.09726e-07, 3.14159, -1.13999e-14 ],
		"quaternion": [ -1.55788e-15, 1, 5.48632e-08, 7.54979e-08 ],
		"scale"     : [ 0.162535, 0.162535, 0.162535 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"lamp.004" : {
		"geometry"  : "geo_lamp",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -8.61181, 4.05676, -2.32864 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.555175, 0.555175, 0.555175 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"lamp.003" : {
		"geometry"  : "geo_lamp",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -12.2649, 4.05676, -2.34784 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.555175, 0.555175, 0.555175 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"lamp.002" : {
		"geometry"  : "geo_lamp",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -12.2649, 4.05676, 1.3992 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.555175, 0.555175, 0.555175 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"lamp.001" : {
		"geometry"  : "geo_lamp",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -8.61181, 4.05676, 1.3992 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 0.555175, 0.555175, 0.555175 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"LandingPad.001" : {
		"geometry"  : "geo_LandingPad",
		"groups"    : [  ],
		"material"  : "mat_Ship",
		"position"  : [ -10.4322, 3.91186, -0.456905 ],
		"rotation"  : [ -1.5708, 0, 1.5708 ],
		"quaternion": [ -0.5, 0.5, 0.5, 0.5 ],
		"scale"     : [ 1.2542, 1.2542, 1.2542 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_LandingPad.001" : {
		"geometry"  : "geo_col_LandingPad",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -12.6731, 3.39717, -0.444305 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 3.42496, 0.456277, 0.261993 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.021" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small" ],
		"material"  : "",
		"position"  : [ 4.99541, 21.5294, 1.19788 ],
		"rotation"  : [ 0.526665, 0.374667, 2.91033 ],
		"quaternion": [ 0.208125, -0.233291, 0.947894, 0.0612944 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.021" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 5.2036, 22.3918, 1.60462 ],
		"rotation"  : [ -2.87392, 0.667678, 0.275111 ],
		"quaternion": [ -0.921502, 0.171704, -0.304388, 0.169409 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.020" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 3.35878, 18.9796, -4.89096 ],
		"rotation"  : [ 2.46008, 1.02003, -0.779864 ],
		"quaternion": [ 0.698793, 0.46358, 0.314712, 0.444677 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.020" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small" ],
		"material"  : "",
		"position"  : [ 3.71795, 18.8091, -3.99966 ],
		"rotation"  : [ -1.34905, -0.0824952, -2.76337 ],
		"quaternion": [ -0.0856702, -0.618923, -0.761588, 0.171986 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.019" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small" ],
		"material"  : "",
		"position"  : [ 8.52829, 18.3956, -2.45302 ],
		"rotation"  : [ -0.376181, -2.35223, -1.75274 ],
		"quaternion": [ 0.650822, -0.635575, -0.179797, 0.374363 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.019" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 9.20431, 18.3095, -3.15166 ],
		"rotation"  : [ -1.46569, 0.230861, 2.34989 ],
		"quaternion": [ -0.177254, 0.646155, 0.651522, 0.355786 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.018" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 7.90014, 16.5687, 1.06587 ],
		"rotation"  : [ -0.883748, 0.795379, 0.420359 ],
		"quaternion": [ -0.312543, 0.424643, 0.0119045, 0.849619 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.018" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small" ],
		"material"  : "",
		"position"  : [ 7.62135, 17.3538, 0.557422 ],
		"rotation"  : [ -0.508107, 2.92178, -0.297053 ],
		"quaternion": [ -0.16963, 0.94739, -0.262773, 0.0680278 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.017" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small" ],
		"material"  : "",
		"position"  : [ 2.863, 17.6891, 0.81391 ],
		"rotation"  : [ -0.341132, 2.90977, 0.476535 ],
		"quaternion": [ 0.211958, 0.955854, -0.136938, 0.150546 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.017" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 2.4273, 16.8374, 1.00711 ],
		"rotation"  : [ 0.215941, 0.705646, -0.62671 ],
		"quaternion": [ -0.00969703, 0.357979, -0.252156, 0.898985 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.016" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small2", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 8.75577, 3.77244, 0.948455 ],
		"rotation"  : [ 0.215941, 0.705646, -0.62671 ],
		"quaternion": [ -0.00969703, 0.357979, -0.252156, 0.898985 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.016" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small2" ],
		"material"  : "",
		"position"  : [ 9.19147, 4.62411, 0.755253 ],
		"rotation"  : [ -0.341132, 2.90977, 0.476535 ],
		"quaternion": [ 0.211958, 0.955854, -0.136938, 0.150546 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.015" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small2" ],
		"material"  : "",
		"position"  : [ 12.4782, 6.80552, 1.08564 ],
		"rotation"  : [ 0.26229, -0.339755, 2.65628 ],
		"quaternion": [ -0.13173, -0.165385, 0.943202, 0.256252 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.015" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small2", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 12.9075, 7.59992, 1.45602 ],
		"rotation"  : [ 2.27526, 1.10085, 1.33051 ],
		"quaternion": [ -0.744144, 0.304771, -0.594332, 0.0115732 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.014" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small2", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 11.4205, 7.34565, -3.4583 ],
		"rotation"  : [ 2.63379, 0.760591, -0.311353 ],
		"quaternion": [ 0.87346, 0.231465, 0.318786, 0.286124 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.014" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small2" ],
		"material"  : "",
		"position"  : [ 11.6371, 6.63406, -2.82646 ],
		"rotation"  : [ -0.791071, 0.277824, -2.90871 ],
		"quaternion": [ -0.171241, -0.364163, -0.913911, 0.0531837 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.013" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small2" ],
		"material"  : "",
		"position"  : [ 9.46601, 6.64892, 0.168247 ],
		"rotation"  : [ -0.252159, 0.305338, -2.29631 ],
		"quaternion": [ -0.188572, -0.051465, -0.90209, 0.384742 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.013" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small2", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 8.76962, 7.33078, 0.219244 ],
		"rotation"  : [ -2.58991, 0.423531, -0.899004 ],
		"quaternion": [ -0.872131, -0.357193, -0.29785, 0.151944 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.012" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_Asteroid_small2", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 13.9449, 3.69068, -0.494595 ],
		"rotation"  : [ -1.49228, -1.99018, -1.14325 ],
		"quaternion": [ 0.0224174, -0.71796, 0.262591, 0.644265 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.012" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [ "grp_Asteroid_small2" ],
		"material"  : "",
		"position"  : [ 13.5833, 4.53106, -0.8344 ],
		"rotation"  : [ -0.505478, 0.294338, 0.397593 ],
		"quaternion": [ -0.214443, 0.188033, 0.153203, 0.946143 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.011" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -1.48694, 3.90223, -0.840174 ],
		"rotation"  : [ -0.152957, 0.288442, 0.91428 ],
		"quaternion": [ -0.00459614, 0.16196, 0.425671, 0.890254 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.011" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -0.745799, 3.27999, -0.966752 ],
		"rotation"  : [ 1.83461, -0.707424, 1.61185 ],
		"quaternion": [ 0.363809, -0.683182, 0.221041, 0.593335 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.010" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -4.96742, 4.80945, -0.0502164 ],
		"rotation"  : [ -2.50026, 0.886722, -0.894785 ],
		"quaternion": [ -0.831391, -0.248963, -0.490219, 0.0805784 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.010" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -4.4863, 3.96715, 0.0572405 ],
		"rotation"  : [ -0.112755, -0.024952, -2.62591 ],
		"quaternion": [ -0.00232296, -0.0576566, -0.965152, 0.255248 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.009" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -10.3894, -2.00724, -1.15592 ],
		"rotation"  : [ -0.29349, -0.0319761, 0.357394 ],
		"quaternion": [ -0.146683, 0.010423, 0.178115, 0.97296 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.009" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -10.0481, -2.87928, -0.880971 ],
		"rotation"  : [ -0.838863, -2.20395, -0.632226 ],
		"quaternion": [ 0.0784038, -0.831606, 0.217011, 0.505164 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.008" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -14.8115, 0.123868, 3.19151 ],
		"rotation"  : [ 1.49174, -0.420408, 2.80017 ],
		"quaternion": [ -0.0382844, -0.680062, 0.683834, 0.261574 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.008" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -15.1098, 0.18419, 2.26422 ],
		"rotation"  : [ -1.28773, -0.59306, 0.377529 ],
		"quaternion": [ -0.607746, -0.121822, 0.315817, 0.718376 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.007" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -16.3138, -3.63925, -1.87594 ],
		"rotation"  : [ 0.161225, 2.76038, 0.822147 ],
		"quaternion": [ 0.405068, 0.891071, 0.14794, 0.141515 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.007" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -16.9774, -4.25222, -2.24514 ],
		"rotation"  : [ 0.927703, 0.385249, -0.823899 ],
		"quaternion": [ 0.333834, 0.332707, -0.272984, 0.838654 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.006" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -18.6468, 1.83763, 1.53584 ],
		"rotation"  : [ 0.362693, 0.226817, -1.11218 ],
		"quaternion": [ 0.0934381, 0.18913, -0.498544, 0.840805 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.006" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -17.7941, 2.31141, 1.50515 ],
		"rotation"  : [ -0.593814, 2.86761, 1.13741 ],
		"quaternion": [ 0.476491, 0.819699, -0.173878, 0.266114 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.005" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -16.6606, 14.1096, -1.85061 ],
		"rotation"  : [ 0.0718002, 2.30877, 2.03891 ],
		"quaternion": [ 0.786134, 0.466394, 0.361518, 0.183782 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.005" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -17.2466, 14.5951, -2.46173 ],
		"rotation"  : [ 1.60437, -0.670433, -0.873019 ],
		"quaternion": [ 0.71189, 0.0797697, -0.491848, 0.494909 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.004" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -20.9174, 9.05212, 0.593728 ],
		"rotation"  : [ 2.43882, -0.167222, -1.40062 ],
		"quaternion": [ 0.733937, 0.580984, -0.281001, 0.211736 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.004" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -19.969, 8.82253, 0.578393 ],
		"rotation"  : [ -1.79517, 0.228355, -1.50308 ],
		"quaternion": [ -0.616011, -0.478427, -0.488012, 0.391769 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.003" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -16.4074, 13.8293, 1.6298 ],
		"rotation"  : [ -1.57344, 1.26642, -0.446316 ],
		"quaternion": [ -0.6491, 0.281187, -0.534569, 0.462427 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.003" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -16.5337, 14.2335, 2.50909 ],
		"rotation"  : [ -2.12813, -0.768357, -0.180891 ],
		"quaternion": [ -0.79086, -0.254369, 0.285719, 0.477705 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.002" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -10.5282, 16.0394, -3.35116 ],
		"rotation"  : [ -1.8423, 0.0684232, 1.92675 ],
		"quaternion": [ -0.437233, 0.665286, 0.480864, 0.367413 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.002" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -11.4409, 16.1909, -3.04028 ],
		"rotation"  : [ 2.36213, -0.344621, 1.45704 ],
		"quaternion": [ 0.636614, -0.655329, 0.130864, 0.38489 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Light_2.001" : {
		"geometry"  : "geo_Light_2",
		"groups"    : [  ],
		"material"  : "",
		"position"  : [ -14.7157, 11.7865, -1.29273 ],
		"rotation"  : [ -0.76167, -2.83465, -0.779289 ],
		"quaternion": [ 0.295938, -0.870259, 0.285886, 0.270811 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Light_2.001" : {
		"geometry"  : "geo_col_Light_2",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -14.0619, 11.141, -0.963538 ],
		"rotation"  : [ -1.92135, 0.83303, 1.48102 ],
		"quaternion": [ -0.396838, 0.676769, 0.108762, 0.61047 ],
		"scale"     : [ 0.0912571, 1.47098, 0.0912571 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Asteroid_small_1.001" : {
		"geometry"  : "geo_Asteroid_small_1",
		"groups"    : [ "grp_Asteroid_small" ],
		"material"  : "mat_Asteroid",
		"position"  : [ 5.11948, 19.3479, -0.679632 ],
		"rotation"  : [ 1.5708, -3.14159, 1.50729e-14 ],
		"quaternion": [ -5.33851e-08, 0.707107, 0.707107, -5.33851e-08 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Astroid_Big.001" : {
		"geometry"  : "geo_Astroid_Big",
		"groups"    : [  ],
		"material"  : "mat_Asteroid",
		"position"  : [ -11.4899, 0.262176, -0.233181 ],
		"rotation"  : [ 1.5708, -3.14159, 1.50729e-14 ],
		"quaternion": [ -5.33851e-08, 0.707107, 0.707107, -5.33851e-08 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Asteroid_small_2.001" : {
		"geometry"  : "geo_Asteroid_small_2",
		"groups"    : [ "grp_Asteroid_small2" ],
		"material"  : "mat_Asteroid",
		"position"  : [ 11.4238, 5.76689, -0.419039 ],
		"rotation"  : [ -1.5708, 0, 0 ],
		"quaternion": [ -0.707107, 0, 0, 0.707107 ],
		"scale"     : [ 1, 1, 1 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Asteroid_small_2.001" : {
		"geometry"  : "geo_col_Asteroid_small_2",
		"groups"    : [ "grp_Asteroid_small2", "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ 11.2461, 6.0785, -0.534216 ],
		"rotation"  : [ 1.5708, -3.14159, 1.50729e-14 ],
		"quaternion": [ -5.33851e-08, 0.707107, 0.707107, -5.33851e-08 ],
		"scale"     : [ 2.89754, 4.49782, 2.11962 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"col_Astroid_Big.001" : {
		"geometry"  : "geo_col_Astroid_Big",
		"groups"    : [ "grp_collider" ],
		"material"  : "mat_Collison",
		"position"  : [ -14.7359, -0.850322, -0.213852 ],
		"rotation"  : [ 1.5708, -3.14159, 1.50729e-14 ],
		"quaternion": [ -5.33851e-08, 0.707107, 0.707107, -5.33851e-08 ],
		"scale"     : [ 2.4672, 2.4672, 2.4672 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	},

	"Backdrop" : {
		"geometry"  : "geo_Plane",
		"groups"    : [  ],
		"material"  : "mat_Backdrop",
		"position"  : [ 0, 7.96488, -10.3413 ],
		"rotation"  : [ -4.12694e-08, 0, 0 ],
		"quaternion": [ -2.06347e-08, 0, 0, 1 ],
		"scale"     : [ 3.95228, 3.95228, 3.95228 ],
		"visible"       : true,
		"castShadow"    : false,
		"receiveShadow" : false,
		"doubleSided"   : false
	}
},


"geometries" :
{
	"geo_Antenna.000" : {
		"type" : "ascii",
		"url"  : "level_1.Antenna.000.js"
	},

	"geo_Ship_conductor" : {
		"type" : "ascii",
		"url"  : "level_1.Ship_conductor.js"
	},

	"geo_Ship_Thruster" : {
		"type" : "ascii",
		"url"  : "level_1.Ship_Thruster.js"
	},

	"geo_Ship_Foot" : {
		"type" : "ascii",
		"url"  : "level_1.Ship_Foot.js"
	},

	"geo_Ship_Head" : {
		"type" : "ascii",
		"url"  : "level_1.Ship_Head.js"
	},

	"geo_col_Asteroid_small_1" : {
		"type" : "ascii",
		"url"  : "level_1.col_Asteroid_small_1.js"
	},

	"geo_SolarPanal" : {
		"type" : "ascii",
		"url"  : "level_1.SolarPanal.js"
	},

	"geo_Sattelite_1_cell.011" : {
		"type" : "ascii",
		"url"  : "level_1.Sattelite_1_cell.011.js"
	},

	"geo_Sattelite_1_cell.010" : {
		"type" : "ascii",
		"url"  : "level_1.Sattelite_1_cell.010.js"
	},

	"geo_Sattelite_1_cell.009" : {
		"type" : "ascii",
		"url"  : "level_1.Sattelite_1_cell.009.js"
	},

	"geo_Sattelite_1_cell.008" : {
		"type" : "ascii",
		"url"  : "level_1.Sattelite_1_cell.008.js"
	},

	"geo_Sattelite_1_cell.007" : {
		"type" : "ascii",
		"url"  : "level_1.Sattelite_1_cell.007.js"
	},

	"geo_Sattelite_1_cell.006" : {
		"type" : "ascii",
		"url"  : "level_1.Sattelite_1_cell.006.js"
	},

	"geo_col_Ship_Head" : {
		"type" : "ascii",
		"url"  : "level_1.col_Ship_Head.js"
	},

	"geo_lamp" : {
		"type" : "ascii",
		"url"  : "level_1.lamp.js"
	},

	"geo_LandingPad" : {
		"type" : "ascii",
		"url"  : "level_1.LandingPad.js"
	},

	"geo_col_LandingPad" : {
		"type" : "ascii",
		"url"  : "level_1.col_LandingPad.js"
	},

	"geo_Light_2" : {
		"type" : "ascii",
		"url"  : "level_1.Light_2.js"
	},

	"geo_col_Light_2" : {
		"type" : "ascii",
		"url"  : "level_1.col_Light_2.js"
	},

	"geo_Asteroid_small_1" : {
		"type" : "ascii",
		"url"  : "level_1.Asteroid_small_1.js"
	},

	"geo_Astroid_Big" : {
		"type" : "ascii",
		"url"  : "level_1.Astroid_Big.js"
	},

	"geo_Asteroid_small_2" : {
		"type" : "ascii",
		"url"  : "level_1.Asteroid_small_2.js"
	},

	"geo_col_Asteroid_small_2" : {
		"type" : "ascii",
		"url"  : "level_1.col_Asteroid_small_2.js"
	},

	"geo_col_Astroid_Big" : {
		"type" : "ascii",
		"url"  : "level_1.col_Astroid_Big.js"
	},

	"geo_Plane" : {
		"type" : "ascii",
		"url"  : "level_1.Plane.js"
	}
},


"textures" :
{
	"UV_Shuttle_DIFF.jpg" : {
		"url": "UV_Shuttle_DIFF.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Asteroid_large_DIFF.jpg" : {
		"url": "UV_Asteroid_large_DIFF.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Asteroid_large_NORM.jpg" : {
		"url": "UV_Asteroid_large_NORM.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Shuttle_NORM.jpg" : {
		"url": "UV_Shuttle_NORM.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Satelite_DIFF.jpg" : {
		"url": "UV_Satelite_DIFF.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Satelite_NORM.jpg" : {
		"url": "UV_Satelite_NORM.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Satelite_SPEC.jpg" : {
		"url": "UV_Satelite_SPEC.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Shuttle_SPEC.jpg" : {
		"url": "UV_Shuttle_SPEC.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"BackdropSpace.jpg" : {
		"url": "BackdropSpace.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"Antenna.png" : {
		"url": "Antenna.png",
        "wrap": ["repeat", "repeat"]
	},

	"inside_DIFF.jpg" : {
		"url": "inside_DIFF.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"inside_NORM.jpg" : {
		"url": "inside_NORM.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"inside_SPEC.jpg" : {
		"url": "inside_SPEC.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Satelite_DIFF.jpg" : {
		"url": "UV_Satelite_DIFF.jpg",
        "wrap": ["repeat", "repeat"]
	},

	"UV_Shuttle_DIFF.jpg" : {
		"url": "UV_Shuttle_DIFF.jpg",
        "wrap": ["repeat", "repeat"]
	}
},


"materials" :
{
	"mat_Asteroid" : {
		"type": "MeshPhongMaterial",
		"parameters": { "color": 10132122, "opacity": 1, "ambient": 10132122, "specular": 0, "shininess": 5e+01, "map": "UV_Asteroid_large_DIFF.jpg", "normalMap": "UV_Asteroid_large_NORM.jpg", "vertexColors": "vertex", "blending": "NormalBlending" }
	},

	"mat_Backdrop" : {
		"type": "MeshBasicMaterial",
		"parameters": { "color": 10724259, "opacity": 1, "map": "BackdropSpace.jpg", "blending": "NormalBlending" }
	},

	"mat_Collison" : {
		"type": "MeshLambertMaterial",
		"parameters": { "color": 8411167, "opacity": 0.58, "transparent": true, "blending": "NormalBlending" }
	},

	"mat_Light" : {
		"type": "MeshBasicMaterial",
		"parameters": { "color": 16777215, "opacity": 1, "map": "UV_Satelite_DIFF.jpg", "vertexColors": "vertex", "blending": "AdditiveBlending" }
	},

	"mat_Satelite" : {
		"type": "MeshPhongMaterial",
		"parameters": { "color": 13421772, "opacity": 1, "ambient": 13421772, "specular": 0, "shininess": 5e+01, "map": "UV_Satelite_DIFF.jpg", "specularMap": "UV_Satelite_SPEC.jpg", "normalMap": "UV_Satelite_NORM.jpg", "normalMapFactor": 0.5, "vertexColors": "vertex", "blending": "NormalBlending" }
	},

	"mat_SateliteInside" : {
		"type": "MeshPhongMaterial",
		"parameters": { "color": 13421772, "opacity": 1, "ambient": 13421772, "specular": 0, "shininess": 5e+01, "map": "inside_DIFF.jpg", "specularMap": "inside_SPEC.jpg", "normalMap": "inside_NORM.jpg", "normalMapFactor": 0.5, "blending": "NormalBlending" }
	},

	"mat_Ship" : {
		"type": "MeshPhongMaterial",
		"parameters": { "color": 10724259, "opacity": 1, "ambient": 10724259, "specular": 8355711, "shininess": 5e+01, "map": "UV_Shuttle_DIFF.jpg", "specularMap": "UV_Shuttle_SPEC.jpg", "normalMap": "UV_Shuttle_NORM.jpg", "normalMapFactor": 0.5, "blending": "NormalBlending" }
	},

	"mat_ship_antenna" : {
		"type": "MeshLambertMaterial",
		"parameters": { "color": 0, "opacity": 1, "map": "Antenna.png", "transparent": true, "blending": "NormalBlending" }
	},

	"Material" : {
		"type": "MeshBasicMaterial",
		"parameters": { "color": 1483536, "opacity": 1, "vertexColors": "vertex", "blending": "MultiplyBlending" }
	}
},


"transform" :
{
	"position"  : [ 0, 0, 0 ],
	"rotation"  : [ -1.5708, 0, 0 ],
	"scale"     : [ 1, 1, 1 ]
},

"defaults" :
{
	"bgcolor" : [ 0, 0, 0 ],
	"bgalpha" : 1.000000,
	"camera"  : ""
}

}
