{

	"metadata" :
	{
		"formatVersion" : 3.1,
		"generatedBy"   : "Blender 2.66 Exporter",
		"vertices"      : 4,
		"faces"         : 1,
		"normals"       : 1,
		"colors"        : 1,
		"uvs"           : [4],
		"materials"     : 1,
		"morphTargets"  : 0,
		"bones"         : 0
	},

	"scale" : 1.000000,

	"materials" : [	{
		"DbgColor" : 15658734,
		"DbgIndex" : 0,
		"DbgName" : "mat_Backdrop",
		"blending" : "NormalBlending",
		"colorAmbient" : [0.6400000190734865, 0.6400000190734865, 0.6400000190734865],
		"colorDiffuse" : [0.6400000190734865, 0.6400000190734865, 0.6400000190734865],
		"colorSpecular" : [0.5, 0.5, 0.5],
		"depthTest" : true,
		"depthWrite" : true,
		"mapDiffuse" : "BackdropSpace.jpg",
		"mapDiffuseWrap" : ["repeat", "repeat"],
		"shading" : "Basic",
		"specularCoef" : 50,
		"transparency" : 1.0,
		"transparent" : false,
		"vertexColors" : false
	}],

	"vertices" : [16,-9,0,-16,-9,0,16,9,0,-16,9,0],

	"morphTargets" : [],

	"normals" : [0,0,1],

	"colors" : [16777215],

	"uvs" : [[7.5e-05,7.5e-05,0.999925,7.5e-05,0.999925,0.996085,7.5e-05,0.996085]],

	"faces" : [171,1,0,2,3,0,0,1,2,3,0,0,0,0,0,0,0,0],

	"bones" : [],

	"skinIndices" : [],

	"skinWeights" : [],

	"animation" : {}


}
