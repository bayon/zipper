var GUI_canvas;
var GUI_ctx;

function init_GUI()
{
    //Create the GUI canvas
    GUI_canvas = document.createElement('canvas');
    GUI_canvas.setAttribute('width', x*2);
    GUI_canvas.setAttribute('height', 50);
    document.getElementById("wrapper").appendChild(GUI_canvas);
    GUI_ctx = GUI_canvas.getContext('2d');
    GUI_ctx.globalAlpha = 0.6; //Lower the opacity of the GUI
    
    
    //Dispaly feul state
    GUI_ctx.font = "15px Arial";
	GUI_ctx.fillStyle = "#333";
    GUI_ctx.fillText('FEUL', 20, 25);
    GUI_ctx.globalCompositeOperation = "destination-over";
    GUI_ctx.rect(10,10,feul,20);
    GUI_ctx.fillStyle = 'white';
    GUI_ctx.fill();
    
    //Display collected debris state 
    GUI_ctx.font = "25px Arial bold";
	GUI_ctx.fillStyle = "white";
    GUI_ctx.fillText(collectedDebris +'/' +debris.length, x*2 - 45, 25);
    
    //Display the amount of lives
    for (var i=0;i<lives;i++)
    { 
        GUI_ctx.drawImage(imageObj, x+49 * i - 29, 10,49,34);
    }
    
}

function update_GUI()
{
    GUI_ctx.clearRect ( 0 , 0 , x*2 , 100 );//Clear th whole GUI canvas
    
    //Update feul state
   GUI_ctx.font = "15px Arial";
	GUI_ctx.fillStyle = "#333";
    GUI_ctx.fillText('FEUL', 20, 25);
    GUI_ctx.globalCompositeOperation = "destination-over";    
    GUI_ctx.fillStyle = 'white';
    GUI_ctx.fillRect(10,10,feul,20);
    
    
    //Update collected debris state
     GUI_ctx.font = "25px Arial bold";
	GUI_ctx.fillStyle = "white";
    GUI_ctx.fillText(collectedDebris +'/' +debris.length, x*2 - 45, 25);
    
    //Update the amount of lives
    for (var i=0;i<lives;i++)
    { 
        GUI_ctx.drawImage(imageObj, x+49 * i - 29, 10,49,34);
    }
}