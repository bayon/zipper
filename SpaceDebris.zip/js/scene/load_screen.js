var ctx;
var imageObj;
var logo;
var audio = [];
var soundArray;
var w = 200;
var h = 200;
var r = Math.floor(w / 2);
var l = Math.ceil(5 * w / 200) + 3;
var x = window.innerWidth / 2;
var y = window.innerHeight / 2;
var loadedAudio = 0;

function preload()
{
    //Load the images for the instructions
    imageObj = new Image();
    imageObj.onload = function() {load_sound();}//Load the Blender scene and display it on the canvas once this image is loaded
    imageObj.src = "img/loadScreen.png";
    
    logo = new Image();
    logo.onload = function() {}
    logo.src = "img/logo_l_small.png";
    
    if(y<500){y=500;}
}

function load_sound()
{
    //Load Audio Files
    soundArray = ["sound/thruster.wav","sound/explosion.wav","sound/background.wav","sound/collected.wav"]
    
    for (var i=0; i<soundArray.length;i++)
    { 
        sound = new Audio('audio'); //Add sound element
        sound.setAttribute('src', soundArray[i]);// load all sounds from the soundArray
        sound.addEventListener('loadeddata', function(){loadedAudio++;initLoadscreen(loadedAudio);if(loadedAudio == soundArray.length){load_blenderScene();}}, false);
//        if(i == soundArray.length-1){sound.addEventListener('loadeddata', initLoadscreen(i),load_blenderScene(), false);} //If the last object is loaded -> start loading blender scene
        audio.push(sound)// Push the loaded sound to a new array
    }
}

function initLoadscreen(current)
{
    
    //Simple loading animation. Triggered every time a model or texture has loaded
    ctx.drawImage(imageObj, x-99, y - 50,198,138);
    ctx.fill
    
    ctx.globalCompositeOperation = "source-atop";
    ctx.rect(x-100, y-50,198/100*current,138);
    ctx.fillStyle = 'yellow';
    ctx.fill();
    
    ctx.fillStyle = 'rgb(2, 3, 3)';
    var size = 10 + Math.ceil(30 * w / 200);
    ctx.font = size + 'px Melbourne-Bold';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(current , x, y);
    
}

function introduction()
{
    
    //Add Game instructions and play button to the canvas
    ctx.drawImage(imageObj, x-99, y - 50,198,138);
    ctx.fill
    
    ctx.globalCompositeOperation = "source-atop";
    ctx.rect(x-100, y-50,198,138);
    ctx.fillStyle = 'yellow';
    ctx.fill();
    
    ctx.fillStyle = '#333';
    var size = 10 + Math.ceil(30 * w / 200);
    ctx.font = size + 'px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText("play" , x, y);
    
    ctx.globalCompositeOperation = "destination-over";
     ctx.rect(x-150, y-500,300,600);
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = 'grey';
    ctx.fill();
    
     ctx.globalCompositeOperation = "source-atop";
    ctx.fillStyle = 'yellow';
    var size = 10 + Math.ceil(30 * w / 200);
    ctx.font = size + 'px Arial';
    ctx.globalAlpha = 1;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText("SpaceDebris" , x, 20);
    
      ctx.globalCompositeOperation = "source-atop";
    ctx.fillStyle = '#333';
    var size = 18;
    ctx.font = size + 'px Arial';
    ctx.globalAlpha = 1;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText("A game made with Blender and", x-140, 60);
    ctx.fillText("the threeJS library.", x-140, 80);
    ctx.fillText("Clean the space by bringing", x-140, 120);
    ctx.fillText("the garbage one by one to the", x-140, 140);
    ctx.fillText("landingpad.", x-140, 160);
    ctx.fillText("You will receive feul for each", x-140, 180);
    ctx.fillText("piece you return!", x-140, 200);
    ctx.fillText("Tap the arrow keys to navigate", x-140, 240);
    
    ctx.drawImage(logo, x-140, 300,1000,50);
    ctx.font = 13 + 'px Arial';
    ctx.fillStyle = 'white';
    ctx.fillText("See the documentation & get the code for free", x-140, 360);
     ctx.fill
    ctx.save
    
    //Add click event to the instructions panel
    canvas.addEventListener('click', function(event) 
                            {
                                if((event.clientX < x + 100 && event.clientX > x - 100)&&(event.clientY < y + 60 && event.clientY > y - 60)){ready()};//Press Play
                                if((event.clientX < x +150 && event.clientX > x - 140)&&(event.clientY > 300 && event.clientY < 350))
                                {window.open("http://www.inkfood.com/spacedebris/", '_blank');};//Press Link
                            })
}