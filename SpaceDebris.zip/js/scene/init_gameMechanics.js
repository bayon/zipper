var clock = new THREE.Clock();

function init_gameMechanics()
{
}
function collisionDetection()
{
    // collision detection:
	//   determines if any of the rays from the cube's origin to each vertex
	//		intersects any face of a mesh in the array of target meshes
	//   for increased collision accuracy, add more vertices to the cube;
	//		for example, new THREE.CubeGeometry( 64, 64, 64, 8, 8, 8, wireMaterial )
	//   HOWEVER: when the origin of the ray is within the target mesh, collisions do not occ

    var originPoint = player.position.clone();
    for (var vertexIndex = 0; vertexIndex < loadedObjects.objects["col_Ship_Head.001"].geometry.vertices.length; vertexIndex++)
	{		
		var localVertex = loadedObjects.objects["col_Ship_Head.001"].geometry.vertices[vertexIndex].clone();
		var globalVertex = localVertex.applyMatrix4( loadedObjects.objects["col_Ship_Head.001"].matrix );
		var directionVector = globalVertex.sub( loadedObjects.objects["col_Ship_Head.001"].position );
		var ray = new THREE.Raycaster( originPoint, directionVector.clone() );
        
		var collisionResults = ray.intersectObjects( collidableMeshList );
		if ( collisionResults.length > 0 && collisionResults[0].distance < directionVector.length() && !explode) 
       
        // COLLISION DETECTED
        { 
            //If collide with the landingPad & low speed
            if(collisionResults[0].object.name == "col_LandingPad.001" && yspeed > -0.07)
            {
                if(currentDebris != null) //Got something to deliver -> Get points an feul
                {
                    collectedDebris +=1; //Add one to the collected debris
                    audio[3].play();//Play collected sound
                    feul = 100;//reset feul
                    currentDebris = null; //reset to null
                    update_GUI();//Update GUI
                    if(collectedDebris == debris.length){reset_game();}//If every debris is collected -> Reset the game
                }
                
//                console.log(xspeed+","+yspeed); //DEBUG Get current speed while landing
                
                xspeed = yspeed = 0; //set the speed to zero
                landed = true;
                return;
            }
            else //If collide with anything else or speed is to high to land
            {
                lives -= 1; //Remove one live 
                xspeed = yspeed = 0; //set the speed to zero
                addExplosion(); //add explosion animation
                update_GUI(); 
                
                return; 
            }
        }
        else{landed = false}
    }
}

function update_Player()
{   
    playerControll();
    
    //Update Player position add gravity and friction
    if(xspeed != 0 || yspeed != 0 )
    {
        yspeed -= gravity;
        xspeed *= friction;
        yspeed *= friction;
        player.position.y += yspeed;
        player.position.x += xspeed;
    }
    collisionDetection();
    
    //Out of bounds
    if(player.position.y < -16 && !explode){lives -= 1; //Remove one live 
                xspeed = yspeed = 0; //set the speed to zero
                addExplosion(); //add explosion animation
                update_GUI(); }
    
    if(landed)
    {
        landingPad_light.color.set(0x42DB44);//Change the landingPad light object material to green
        loadedObjects.objects["lamp.001"].material.materials[1].color.setHex(0x42DB44)//Change the landing pad light to green
    }
    else if(currentDebris == null)
    {
        landingPad_light.color.set(0xF22C2C);//Change the landingPad light object material to red
        loadedObjects.objects["lamp.001"].material.materials[1].color.setHex(0xF22C2C)//Change the landing pad light to red
    }
    
    for (var i=0;i<debris.length;i++)//Loop trough the debris Array
    {
        //Check if the player position is equal to any of the debris with a tolerance of 1
        if((player.position.x >= debris[i].position.x - 1 && player.position.x <= debris[i].position.x + 1) &&
           (player.position.y >= debris[i].position.y - 1 && player.position.y <= debris[i].position.y + 1))
        {
            //Only one of the debris can be collected, and check if is still in the scene
            if(currentDebris == null && scene.getChildByName( debris[i].name, true ))//If no item is collected get one
            {
                currentDebris = debris[i];//Get the collected debris
                landingPad_light.color.set(0x42DB44);//Change the landingPad light object material to green
                audio[3].play();
                loadedObjects.objects["lamp.001"].material.materials[1].color.setHex(0x42DB44)//Change the landing pad light to green
                scene.remove( debris[i]);//Remove the collected debris and its children from the scene
            }
        }
    } 
}

function reset_player()
{
    if(currentDebris != null){scene.add(currentDebris);}//If a debris is collected -> Reset to scene
    currentDebris = null;//Set the current debris to null
    feul = 100;//Reset feul
    player.position.set(player.startPosition.x,player.startPosition.y,player.startPosition.z); //Reset Player position to the start position
    loadedObjects.objects["Player_Ship"].traverse( function ( object ) { object.visible = true; } ); //Display player after explosion
    particleGroup.traverse( function ( object ) { object.visible = false; } ); //Remove any thruster particle 
    loadedObjects.objects["col_Ship_Head.001"].visible = false; //make collider of the player invisible
    if(lives > 0){readyToPlay = true;} //If you still got lives -> ready to play
    else{reset_game();} // else -> reset game
}

function reset_game()
{
    
    //Reset all the game states for a new start
    readyToPlay = false;
    lives = 3;
    feul = 100;
    camera.position.set(0,8,50);
    collectedDebris = 0;
    
    
     for (var i=0;i<debris.length;i++)//Loop trough the debris Array and add them back to scene
    {
        scene.add(debris[i]);
    }
    document.getElementById("wrapper").removeChild(GUI_canvas);//Remove the GUI
    //Get the instructions and the play button back
    addCanvas();
    introduction();
}