var scene, camera, renderer;
var groups;
var loadedObjects;
var readyToPlay = false;
var camera_dist;
var count = 0;

function load_blenderScene()
{
    
    initRender();
    load_blenderFile();
}

function initRender()//init the threeJS Render
{
    
    scene = new THREE.Scene();//Create a new threeJS scene
    
    var SCREEN_WIDTH = window.innerWidth, SCREEN_HEIGHT = window.innerHeight;
    renderer = new THREE.WebGLRenderer({antialias:true});//init the render which creates a new canvas element
    renderer.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
    document.getElementById("wrapper").appendChild( renderer.domElement );//Pass the canvas to the DOM
    renderer.domElement.id = "canvas_threeJS";//Add an id to the canvas for later access
    initLoadscreen(0)//Add the loading screen with a value of 0%
    
    //Add a camera to the scene
    var VIEW_ANGLE = 45, ASPECT = SCREEN_WIDTH / SCREEN_HEIGHT, NEAR = 0.1, FAR = 20000;
	camera = new THREE.PerspectiveCamera( VIEW_ANGLE, ASPECT, NEAR, FAR);
	camera.position.set(0,8,50);
    scene.add(camera)
    
    //Add the ambient light, since this is not exportet from blender
    var ambientLight = new THREE.AmbientLight(0x003940);
    scene.add(ambientLight)
    
    // CONTROLS
	controls = new THREE.TrackballControls( camera );
    
    //Add a pointlight
    var light = new THREE.PointLight(0xFCFAD9,0.8);
	light.position.set(0,10,10);
    scene.add(light)
}

function load_blenderFile()
{
     //Create Scene loader and add while_load(callbackProgress) and end_load(callbackFinished) events
    var loader = new THREE.SceneLoader();
    loader.callbackProgress = callbackProgress;
        
    //Scene to load
    loader.load( "js/blenderScene/level_1.js", callbackFinished );
}

function callbackProgress( progress, result ) 
{

    total = progress.totalModels + progress.totalTextures; //Get the total amount of models an materials to load
    loaded = progress.loadedModels + progress.loadedTextures; //Get the amount of already loaded models an materials

    if ( total )
    { 
        //Get percentages of loaded elements back
        bar = Math.floor( loaded / total * 96 + 4 );
    }
      
    initLoadscreen(bar); //Update the loading bar each time it changes
    
    //load each material by passing them to the handle_update function
    for ( var m in result.materials ) count++;
    handle_update( result, Math.floor( count/total ) );

}


//Load progress has finished
function callbackFinished( result ) 
{
    
    
    loadedObjects = result;
    
    //Display the render canvas from threeJS
    document.getElementById("canvas_threeJS").style.opacity = 1;
    introduction();
    
    //Get all the groups we have created in Blender and pass each of them to the array of groups
    groups = result.groups;
    
//    console.log(groups) //DEBUG   Log the name of each group you import
//    console.log(result.geometries) //DEBUG    Keep controll of what geometries you load. Best practice to use the same geometrie multiple times
//    console.log(scene) //DEBUG    Log the whole scene to know exactly whats rendered  
    
    
    //Get Name of each object and add them to the scene
    for( var name in result.objects ) 
    {            
//        console.log(result.objects[name].name) //DEBUG    Log the name of each object you import
        mesh = result.objects[name];
        
        scene.add(mesh); //Add each object to the scene
    }
    
//     scene.add(result.scene); //Instead of add each object seperate to the scene just replace the existin scene with the loaded one
    
    //to Access any object by name
//    result.objects["Ship_Head.001"].position.set(0,1,0)
     
    //if everything loaded correctly go on with game mechanics
    init_blenderScene();//Preparing the loaded objects to be animated
    init_player();//Preparing the Player_Ship
    
}

function handle_update( result, pieces ) {
                
                //Load material for each object
				var m,g, material;
                //For each material we have found
				for ( m in result.materials ) {
                    
					material = result.materials[ m ];
					if ( ! ( material instanceof THREE.MeshFaceMaterial ) ) {

						if( !material.program ) { 
                            renderer.initMaterial( material, result.scene.__lights);
                        
                        //Map the texture correctly if it is repeated
                        if(material.map){ material.map.wrapS = material.map.wrapT = THREE.RepeatWrapping;}
                                                     
                        count += 1;
							
                        if( count > pieces ) {break;}

						}
					}
                }
}

function ready() //Function triggered by pressing the play button
{
    document.getElementById("wrapper").removeChild(document.getElementById("canvas"));//    Remove the loading canvas from the DOM
    camera_dist = new THREE.Vector3().subVectors(camera.position, player.position)//Get the distance from player to camera
    init_GUI();
    readyToPlay = true;
}