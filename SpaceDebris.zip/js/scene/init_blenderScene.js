var collidableMeshList = []; //Array of objects which cause collision with the player
var debris = []; //Array of collectable debris pieces
var rot = 0;

function init_blenderScene()
{
    init_groups(); //Group the objects we have grouped in Blender
}

function init_groups()
{
    //load all additional Textures
    var ringTexture = THREE.ImageUtils.loadTexture( 'img/ring.png' );
    var spriteMaterial = new THREE.SpriteMaterial( { map: ringTexture, useScreenCoordinates: false, color: 0x33ff36,transparent: true,opacity: 0.6,depthTest: false} );
    
    
    //Loop trough all the diffrent groups
    for( var group in groups ) 
    {
//        console.log(group) //DEBUG    Show all the available groups

        //Check if there is an Empty with the same name as the group
        if(loadedObjects.objects[group])
        {   
            //If so, parent all the elements to the empty
            for (var i=0;i<groups[group].length;i++)
            { 
                loadedObjects.objects[group].add(loadedObjects.objects[groups[group][i]]); //Add the groupped objects to the parent
                //Set the new position relative to its parent
                newPos = loadedObjects.objects[groups[group][i]].position.subVectors(loadedObjects.objects[groups[group][i]].position,loadedObjects.objects[group].position); 
                loadedObjects.objects[group].quaternion.set(0,0,0,0); //Reset any rotation
            }
            
        }
        
        //Find the collider group by name
        if(group == "grp_collider")
        {
            for (var i=0;i<groups[group].length;i++)
            { 
                //Make all the collider objects invisible
                loadedObjects.objects[groups[group][i]].visible = false;
                //Pass all the collider object to the collidableMeshList Array
                collidableMeshList.push(loadedObjects.objects[groups[group][i]])
                //Main character collider object is seperated and should not be in the collidableMeshList Array. Anyway we mak it also invisible
                loadedObjects.objects["col_Ship_Head.001"].visible = false;
            }
        }
        
        
        //Find the collectible group by name
        if(group == "Satelite_Debris")
        {
            for (var i=0;i<groups[group].length;i++)
            { 
                //Add all the collectible objects to the debris Array
                debris.push(loadedObjects.objects[groups[group][i]]);
                
                for (var j=0;j<3;j++)
                { 
                    sprite = new THREE.Sprite( spriteMaterial );
		            sprite.scale.set( 3, 3, 1.0 ); // imageWidth, imageHeight
                    sprite.position.set(0,0,0);
		
		            sprite.material.blending = THREE.AdditiveBlending; // "glowing" sprite
                    loadedObjects.objects[groups[group][i]].add(sprite) //Add the sprit to the debris object
                }
            }
        }
    }
}


function update_Scene()
{
    rot += 0.01;
    
    if(readyToPlay)
    {
        //Move camera to start position
        if(camera.position.z > 20)//if camera is not in position
        {
            camera.position.x -= camera_dist.x / 60;
            camera.position.y -= camera_dist.y / 60;
            camera.position.z -= camera_dist.z / 100;
        }
        //If camer is already in start position -> follow the player
        else
        {
            camera.position.x = player.position.x;
            camera.position.y = player.position.y;
                camera.lookAt(player.position);
        }
        
    }
    
    //Rotate each of the debris objects
     for (var i=0;i<debris.length;i++)
        { 
            debris[i].quaternion.setFromEuler(new THREE.Vector3( rot, rot, 0 ));
        }
    
    //Rotate the parent of the Asteroid_1 this also rotates any child of it around the same pivot
    loadedObjects.objects["grp_Asteroid_small"].quaternion.setFromEuler(new THREE.Vector3( rot, rot, 0 ));
    loadedObjects.objects["grp_Asteroid_small2"].quaternion.setFromEuler(new THREE.Vector3( rot, rot, 0 ));
}