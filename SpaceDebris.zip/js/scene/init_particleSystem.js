var particleCount = 0;
var particlePool = [];
var emitterLight;
var emit = false;
var explode = false;
var totalParticles = 200;


function addParticleSystem(){
    
    //Prepare the particle system
	particleGroup = new THREE.Object3D();
    //Add custom properties to each particle
	particleAttributes = { age: [], direction: []};
    //Load the Particle Texture
	particleTexture = THREE.ImageUtils.loadTexture( 'img/particle.png' );
    
    //Add the emmiter light to the scene
    emitterLight = new THREE.PointLight(0x003847,1,300);
    player.add(emitterLight);

    //Fill the particle pool with particles
    for( var i = 0; i < totalParticles; i++ ) 
	{
	    var spriteMaterial = new THREE.SpriteMaterial( { map: particleTexture, useScreenCoordinates: false, color: 0xffffff,transparent: true,opacity: 0.8} );
		
		sprite = new THREE.Sprite( spriteMaterial );
		sprite.scale.set( 1, 1, 1.0 ); // imageWidth, imageHeight
		sprite.position.set( 0,0,0 );
		sprite.visible = false;// Particles are invisible until they have been used
		sprite.material.color.setHSL( 0.5, 0.9, 0.7 );// Set the color of particle
		
		sprite.material.blending = THREE.AdditiveBlending; // "glowing" particles
		
		particleGroup.add( sprite );
	}
	player.add( particleGroup );
}

//Start emitting the particles

function addParticle(angle,speed,age,size,offsetX,offsetY)
{
    // If there still particles in the pool -> continue emit
    if(particlePool.length < totalParticles -10){
    
    //Add the particles to the scene and give a starting speed
    for( var i = 0; i < 10; i++ ) 
	{
    	var angleInRadians = angle * Math.PI / 180;
        var particle = particleGroup.children[particleCount];
    	
        particle.visible = true; //Set the particles visible
        particle.position.x = offsetX; //Set the startPosition
        particle.position.y = offsetY;
        particle.scale.x = particle.scale.y = size; //Set the start scale
        particle.material.opacity = 0.5; //Set opacity
    
        particle.age = age; // Particle is alive until the age is 0
        
        //Add the starting speed to the particles
        particle.velocity = {x:(speed * Math.random()) * Math.cos(angleInRadians),y:-(speed* Math.random()) * Math.sin(angleInRadians)};
    
        //Add the particle to the current alive pool
        particlePool.push(particle);
        particleCount++;
    }
    emit = true;
    }
}

function addExplosion()
{
    readyToPlay = false; //Cant play while explode
    explode = true; 
    audio[1].volume = 0.6;
    audio[1].play(); //Play explosion sound
    loadedObjects.objects["Player_Ship"].traverse( function ( object ) { object.visible = false; } );// Set the player invisible
    //Add particles for the explosion effect
    for( var i = 0; i < 10; i++ ) 
	{
        addParticle(Math.random()*i*360,i*2*Math.random(),40,2,0,0) //Add random values to simulate an explosion
    }
}

function updateParticles()
{   
	for ( var c = 0; c < particlePool.length; c ++ ) 
	{
        var particle = particlePool[ c ];
        // IF PARTICLE IS ALIVE
        if(particle.age > 0) 
         {
            particle.age -= 1; // decrease particle life
            particle.position.y += particle.velocity.y*0.04; //move particle X
            particle.position.x += particle.velocity.x*0.015; //move particele Y
            particle.scale.x = particle.scale.y -= 0.05;
            
            particle.material.opacity -= 0.02;
         }
         // IF PARTICLE IS DEAD
        else
        {
            particle.visible = false;
            particleCount--;
            particlePool.splice(c, 1); //Remove from particle pool
        }
    }
    
    if(particlePool.length == 0){emit = false;audio[0].pause();audio[0].currentTime=0;} //Stop playing thruster sound if there no more particles
    if(explode && particlePool.length <= 0){explode = false;reset_player();} //Reset player if all explosion particles removed
    
    //Change the emitter light accordingly to the amount of particles alive
    emitterLight.intensity = particleCount * 0.01; 
    emitterLight.distance = particleCount * 1;
    
        

}