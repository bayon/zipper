var player;
var currentDebris = null; //Get the current collected debris
var collectedDebris = 0; //Get all debris collected so far
var thruster = []; //Array of thruster sprites
var landingPad_light;
var landed = true;// If Player is on the landing Pad
var lives = 3;
var feul = 100;

function init_player()
{
    player = loadedObjects.objects["Player_Ship"]; //Add a player variable by getting the parent of the Player_Ship
    player.startPosition = player.position.clone(); //Get the players start position to return by death
    init_landingPad(); //init the landingPad to recieve collected debris
    addParticleSystem();
    
    audio[0].loop = true;
    //Add background sound
    audio[2].loop = true;
    audio[2].volume = 0.3;
    audio[2].play();
    
    
    document.body.addEventListener("keydown", function (e) {keys[e.keyCode] = true;}); //Check for pressed keys
    document.body.addEventListener("keyup", function (e) {keys[e.keyCode] = false;}); //Check for released keys
    
     animate();
}

function init_landingPad()
{
    //Add a pointlight to the landingPad
    landingPad_light = new THREE.PointLight(0x09BA00,0.8,12);
    landingPad_light.position.set(-4,0,0);
    loadedObjects.objects["LandingPad.001"].add(landingPad_light)
}

//////////////////PLAYER_CONTROLS///////////////////////

//All the player movement properties
var power = 0.25;
var yspeed = 0;
var xspeed = 0;
var friction = 0.99;
var gravity = 0.002;
var keys = [];

function playerControll()
{
    var delta = clock.getDelta(); // seconds.
    
    if(readyToPlay && feul > 0){
        update_GUI();
        
    if (keys[38] && !landed) {
        // up arrow
        yspeed -= power * delta;
        audio[0].play(); //Play thruster sound
        audio[0].volume = 0.7;
        feul -= 0.1;//Decrease feul
        addParticle(-90,3,5,1,-0.8,-0.1); //Add thruster particles
        addParticle(-90,3,5,1,0.8,-0.1); //Add thruster particles
    }
     if (keys[40]) {
        // down arrow
        yspeed += power * delta; //Move player
        addParticle(90,2,20,2,0,-1.5); //Add thruster particles
        feul -= 0.15; //Decrease feul
        audio[0].volume = 1;
        audio[0].play(); //Play thruster sound
    }
     if (keys[37] && !landed) {
        // left arrow
        xspeed -= power * delta;
        addParticle(0,4,10,1,1,-0.5); //Add thruster particles
        audio[0].volume = 0.7;
        audio[0].play(); //Play thruster sound
        
        feul -= 0.1;//Decrease feul
    }
     if (keys[39] && !landed) {
        // right arrow
        xspeed += power * delta;
        addParticle(180,4,10,1,-1,-0.5); //Add thruster particles
        audio[0].volume = 0.7;
        audio[0].play(); //Play thruster sound
        
        feul -= 0.1;//Decrease feul
    }
    
    
        }
}
