function init() 
{   
    //Check if webGL is supportet
    if ( ! Detector.webgl )
    {   
        Detector.addGetWebGLMessage();
        document.body.removeChild( document.getElementById( 'wrapper' ) );
        return;
    }
    
//    addStats(); //DEBUG Display FPS
    addCanvas(); //First just add a canvas to the page
    preload();
}

function addStats()
{
    // STATS
	stats = new Stats();
	stats.domElement.style.position = 'absolute';
	stats.domElement.style.bottom = '0px';
	stats.domElement.style.zIndex = 100;
	document.getElementById("wrapper").appendChild( stats.domElement );
}

function addCanvas()//Main canvas for loading screen and threeJS
{
    c = document.createElement("canvas");
    c.id = "canvas";
    c.height = window.innerHeight;
    c.width = window.innerWidth;
    
    document.getElementById("wrapper").appendChild(c);
    
    ctx=c.getContext("2d");
}

function animate() 
{
    requestAnimationFrame( animate );
	render();		
	update();
}

function update()
{
//	stats.update();/ //DEBUG
//    controls.update(); //DEBUG Free Camera move
    update_Scene();
    update_Player();
     updateParticles();
}

function render() 
{
    renderer.render( scene, camera );
}


